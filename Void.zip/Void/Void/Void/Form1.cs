using System.Diagnostics;
using Guna;

namespace Void
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ForlornApi.Api.SetAutoInject(true);
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.ExecuteScript(fastColoredTextBox1.Text);
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Clear();
        }

        private void guna2Button3_Click_1(object sender, EventArgs e)
        {
            ForlornApi.Api.KillRoblox();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            {
                string url = "https://discord.gg/QUdhg3BCE8";

                try
                {
                    // Open the URL in the default web browser
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = url,
                        UseShellExecute = true // Ensures it opens in the default browser
                    });
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred: {ex.Message}");
                }
            }
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
